﻿Module Module1

    Sub Main()
        Dim number(9) As Integer
        Console.WriteLine("Please enter 10 numbers: ")
        For i As Integer = 0 To 9
             number(i) = Console.Readline()
        Next
        Console.WriteLine("Unsorted Array: ")
        For i As Integer = 0 To 9
             Console.WriteLine("[" + i.ToString() + "] = " + number(i).ToString())
        Next
        Array.Sort(number)
        Console.WriteLine("Sorted Array: ")
        For i As Integer = 0 To 9
             Console.WriteLine("[" + i.ToString() + "] = " + number(i).ToString())
        Next
    End Sub

End Module
